<!DOCTYPE html>
<html lang="ja">
<head>
	<meta charset="UTF-8">
	<title>
	<?php if ( is_home() ) { ?>トップページのタイトル
	<?php } elseif ( is_search() ) { ?>検索結果:<?php echo the_search_query(); ?> | サイト名
	<?php } elseif ( is_single() ) { ?><?php wp_title(''); ?> | サイト名
	<?php } elseif ( is_page() ) { ?><?php wp_title(''); ?> | サイト名
	<?php } elseif ( is_category() ) { ?>「<?php single_cat_title(); ?>」一覧 | サイト名
	<?php } elseif ( is_month() ) { ?><?php the_time('Y年F'); ?>の記事 | サイト名
	<?php } elseif ( is_tag() ) { ?>「<?php single_tag_title();?>」一覧 | サイト名
	<?php } else { ?>404エラー | サイト名<?php } ?>
	</title>

	<meta name="description" content="<?php
    $pattern = '/(^.{99})(.+)/u';
    $subject = post_custom('article');
    $matches = array();
    preg_match($pattern, $subject , $matches);
    if ($matches[2] != '') {
        $out = $matches[1] . '...';
    } else {
        $out = $subject;
    }
    echo($out);
	?>" />
	
	<meta name="keywords" content="全ページに入れたいキーワード1,全ページに入れたいキーワード2,全ページに入れたいキーワード3,
	<?php if ( is_home() ) { ?>トップページに入れたいキーワード1,トップページに入れたいキーワード2,トップページに入れたいキーワード3
	<?php } elseif ( is_category() ) { ?><?php single_cat_title(); ?>
	<?php } elseif ( is_tag() ) { ?><?php single_tag_title();?>
	<?php } elseif ( is_search() ) { ?><?php echo the_search_query(); ?>
	<?php } elseif ( is_page() ) { ?><?php wp_title(''); ?>
	<?php } elseif ( is_single() ) { ?><?php if (have_posts()) : ?><?php while (have_posts()) : the_post(); ?><?php wp_title(''); ?>,<?php $cat = get_the_category(); $cat = $cat[0]; { echo $cat->cat_name; } ?>
	<?php endwhile; ?><?php else : ?><?php endif; ?>
	<?php } ?>" />

	<!-- External files -->
	<link rel="stylesheet" href="<?php bloginfo( 'stylesheet_url' ); ?>">

	<!-- Favicon, Thumbnail image -->
	<link rel="shortcut icon" href="<?php bloginfo('template_url'); ?>/images/favicon.ico">
	
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<div id="container">
	
	<!-- Header -->
	
		<header id="header" role="banner">
		
			<div class="header-menus1">
				<?php wp_nav_menu(array('theme_location' => 'header-menus1'));?>
			</div>
			
			<div class="header-right">
				<ul>
					 <li><a href="#" target="_blank"><img src="./img/facebook-icon.png" width="30px" height="30px"></a></li>
					 <li><a href="#" target="_blank"><img src="./img/twitter-icon.png" width="30px" height="30px"></a></li>
					 <li><a href="#" target="_blank"><img src="./img/googleplus-icon.png" width="30px" height="30px"></a></li>
					 <li><a href="#" target="_blank"><img src="./img/feed-icon.png" width="30px" height="30px"></a></li>
				</ul>
			</div>
			
			<h1>
			<a href="<?php bloginfo('url'); ?>" class="blog-title" name="top"><?php bloginfo('name'); ?></a>
			</h1>
			
			<p class="site-description">
				<?php bloginfo('description'); ?>
			</p>
			
			<!-- ヘッダー画像　-->
			<?php if(get_header_image()): ?>
				<div id="header-image"><img src="<?php header_image(); ?>" alt="*" width="<?php echo HEADER_IMAGE_WIDTH; ?>" height="<?php echo HEADER_IMAGE_HEIGHT; ?>" /></div>
			<?php endif; ?>
			<!--　/ヘッダー画像　-->
			
			<div class="header-menus2">
				<?php wp_nav_menu(array('theme_location' => 'header-menus2'));?>
			</div>
			
		</header>
		<!-- /#header -->