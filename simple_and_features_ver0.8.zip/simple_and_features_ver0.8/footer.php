	<!-- Footer -->
	<div id="totop">
		<p><a href="#top">▲ページのトップへ戻る</a></p>
	</div>
	<!-- /totop -->
	
	<div id="footer-wrapper">
    
    	<div class="footer-widget-container">
	
			<div class="footer-widget-left">
				<?php dynamic_sidebar( 'footer-widget-left' ); ?>
			</div>
		
			<div class="footer-widget-center">
				<?php dynamic_sidebar( 'footer-widget-center' ); ?>
			</div>
		
			<div class="footer-widget-right">
				<?php dynamic_sidebar( 'footer-widget-right' ); ?>
			</div>
	
    	</div>
       
	</div>

	<footer id="footer" role="contentinfo">
	
		<div class="footer_copy">
			&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All rights reserved. 
			Theme Design by <a href="http://digi-cyber.net">どらごん(R.K.Designs)</a> 
			from <a href="http://digi-cyber.net">Digi-Cyber.net</a>
		</div>
	
	</footer>

</div>
<!-- /#container --!>

<?php wp_footer(); ?>

</body>

</html>