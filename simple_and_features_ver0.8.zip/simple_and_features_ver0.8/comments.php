<div id="comments">

	<?php wp_list_comments(); ?>

<!-- .comment_form -->
<?php comment_form(); ?>
<!-- .comment_form -->

</div>
<!-- #comments -->
