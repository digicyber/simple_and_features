<?php

/////// フロント向け機能 ///////

//標準フィルターの通過OFF
remove_filter('the_content', 'wpautop');


//favicon表示(フロント)
function blog_favicon() {
  echo '<link rel="shortcut icon" type="image/x-icon" href="'.get_bloginfo('template_url').'/img/favicon.ico" />'."\n";
}
add_action('wp_head', 'blog_favicon');


// ナビゲーションメニュー
add_theme_support('menus');
register_nav_menus(array(
		'header-menus1' => 'ヘッダーメニュー1',
		'header-menus2' => 'ヘッダーメニュー2'
));


//カスタム背景設定
add_custom_background();


//カスタムヘッダー(トップイメージ画像)
add_custom_image_header('','admin_header_style');
function admin_header_style() {}

define('NO_HEADER_TEXT',true);
define('HEADER_IMAGE','%s/header-image.jpg');
define('HEADER_IMAGE_WIDTH',960);
define('HEADER_IMAGE_HEIGHT',100);

register_default_headers(array(
	'image1' => array(
			'url' => '%s/images/header_image.jpg',
			'thumbnail_url' => '%s/images/header-image-thumbnail001.jpg',
			'description' => '画像1',
			),
));


// アイキャッチ画像
add_theme_support( 'post-thumbnails' );
set_post_thumbnail_size(220, 165, true );


//ページネーション
function pagination($pages = '', $range = 4)
{
     $showitems = ($range * 2)+1;  
 
     global $paged;
     if(empty($paged)) $paged = 1;
 
     if($pages == '')
     {
         global $wp_query;
         $pages = $wp_query->max_num_pages;
         if(!$pages)
         {
             $pages = 1;
         }
     }   
 
     if(1 != $pages)
     {
         echo "<div class=\"pagination\"><span>Page ".$paged." of ".$pages."</span>";
         if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<a href='".get_pagenum_link(1)."'>&laquo; First</a>";
         if($paged > 1 && $showitems < $pages) echo "<a href='".get_pagenum_link($paged - 1)."'>&lsaquo; Previous</a>";
 
         for ($i=1; $i <= $pages; $i++)
         {
             if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems ))
             {
                 echo ($paged == $i)? "<span class=\"current\">".$i."</span>":"<a href='".get_pagenum_link($i)."' class=\"inactive\">".$i."</a>";
             }
         }
 
         if ($paged < $pages && $showitems < $pages) echo "<a href=\"".get_pagenum_link($paged + 1)."\">Next &rsaquo;</a>";
         if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($pages)."'>Last &raquo;</a>";
         echo "</div>\n";
     }
}


// ウィジェットエリア
if ( function_exists('register_sidebar') )
    register_sidebar(array(
		'name'=>'side-widget',
		'id' => 'side-widget',
		'before_widget' => "<li class='sidebar-widget'>",
		'after_widget' => "</li>\n",
		'before_title' => "<h3 class='sidebar-widget-title'>",
		'after_title' => "</h3>\n",
));
    register_sidebar(array(
		'name'=>'footer-widget-left',
		'id' => 'footer-widget-left',
		'before_widget' => "<li class='footer-widget'>",
		'after_widget' => "</li>\n",
		'before_title' => "<h3 class='footer-widget-title'>",
		'after_title' => "</h3>\n",
));
    register_sidebar(array(
		'name'=>'footer-widget-center',
		'id' => 'footer-widget-center',
		'before_widget' => "<li class='footer-widget'>",
		'after_widget' => "</li>\n",
		'before_title' => "<h3 class='footer-widget-title'>",
		'after_title' => "</h3>\n",
));
    register_sidebar(array(
		'name'=>'footer-widget-right',
		'id' => 'footer-widget-right',
		'before_widget' => "<li class='footer-widget'>",
		'after_widget' => "</li>\n",
		'before_title' => "<h3 class='footer-widget-title'>",
		'after_title' => "</h3>\n",
));


//セルフピンバック禁止
function no_self_ping( &$links ) {
    $home = get_option( 'home' );
    foreach ( $links as $l => $link )
        if ( 0 === strpos( $link, $home ) )
            unset($links[$l]);
}
add_action( 'pre_ping', 'no_self_ping' );


/////// 管理画面向け機能 ///////

//favicon表示(管理画面)
function admin_favicon() {
  echo '<link rel="shortcut icon" type="image/x-icon" href="'.get_bloginfo('template_url').'/img/favicon.gif" />';
}
add_action('admin_head', 'admin_favicon');

// 管理画面で記事IDを表示
add_filter('manage_posts_columns', 'posts_columns_id', 5);
    add_action('manage_posts_custom_column', 'posts_custom_id_columns', 5, 2);
    add_filter('manage_pages_columns', 'posts_columns_id', 5);
    add_action('manage_pages_custom_column', 'posts_custom_id_columns', 5, 2);
function posts_columns_id($defaults){
    $defaults['wps_post_id'] = __('ID');
    return $defaults;
}
function posts_custom_id_columns($column_name, $id){
    if($column_name === 'wps_post_id'){
            echo $id;
    }
}


?>