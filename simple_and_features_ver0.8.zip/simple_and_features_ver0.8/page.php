<?php get_header(); ?>

<!-- Contents --!>

	<div id="wrapper">
	
		<!-- コンテンツ -->
			<div id="content">
			
			<?php if (have_posts()) : ?>
			
			<?php while (have_posts()) : the_post(); ?>
			
				<div id="post">
				
					<h2>
					<a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>">
					<?php the_title(); ?>
					</a>
					</h2>
					
					<div class="post-info">
					
						<ul>
							<li class="cal">▼<?php the_time('Y年m月d日') ?></li>
							<li class="cat">▼<?php the_category(', ') ?></li>
							<li class="tag">▼<?php the_tags('', ', '); ?></li>
						</ul>
						<br class="clear" />
					
					</div>
				
				<?php if(has_post_thumbnail()) { echo the_post_thumbnail(); } ?>
			
				<?php the_content('続きを読む'); ?>
			
				</div>
				<!-- /.post -->
			
			<?php endwhile; ?>
		    
			<!-- pagination -->
			<?php if (function_exists("pagination")) {
				pagination($additional_loop->max_num_pages);
			} ?>
			<!-- Pagination -->
			
			<?php else : ?>
		 
		    <h2 class="title">Page Not Found : 記事が見つかりませんでした。</h2>
		    <p>検索で見つかるかもしれません。</p><br />
		    <?php get_search_form(); ?>
		 
			<?php endif; ?>

			<!-- Commetns -->
			<?php comments_template(); ?>

		</div>
		<!-- /#content --!>

	</div>
	<!-- /#wrapper --!>

<?php get_sidebar(); ?>
<?php get_footer(); ?>