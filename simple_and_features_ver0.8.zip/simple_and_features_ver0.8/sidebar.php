<!-- Side -->
<div id="sidebar">
	<div class="sidebar-widget-container">
		<ul>
			<?php dynamic_sidebar( 'side-widget' ); ?>
		</ul>
	</div><!-- /.widget-area -->	
</div>

<br class="clear">

<!-- /#side -->